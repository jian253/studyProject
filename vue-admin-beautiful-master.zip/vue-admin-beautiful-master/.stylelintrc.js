/**
 * @author chuzhixin 1204505056@qq.com （不想保留author可删除）
 * @description stylelint
 */
module.exports = {
  extends: ['stylelint-config-recess-order', 'stylelint-config-prettier'],
}
