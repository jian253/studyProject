/**
 * @author chuzhixin 1204505056@qq.com （不想保留author可删除）
 * @description babel.config
 */
module.exports = {
  presets: ['@vue/cli-plugin-babel/preset'],
}
