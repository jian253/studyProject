<template>
  <div class="menu1-container">
    <el-alert :closable="false" title="嵌套路由 1" type="success">
      <router-view />
    </el-alert>
  </div>
</template>
