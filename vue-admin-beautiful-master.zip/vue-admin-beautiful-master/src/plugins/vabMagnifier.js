import VabMagnifier from 'zx-magnifie'

export default VabMagnifier
