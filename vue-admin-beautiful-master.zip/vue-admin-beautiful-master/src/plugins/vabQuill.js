import 'zx-quill/dist/zx-quill.css'
import VabQuill from 'zx-quill'

export default VabQuill
