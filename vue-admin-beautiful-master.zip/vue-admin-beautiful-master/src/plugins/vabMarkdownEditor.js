import ZxMarkdownEditor from 'zx-markdown-editor'
import 'zx-markdown-editor/dist/zx-markdown-editor.css'

const VabMarkdownEditor = ZxMarkdownEditor
export default VabMarkdownEditor
