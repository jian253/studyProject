/**
 * @author chuzhixin 1204505056@qq.com （不想保留author可删除）
 * @description webstorm.config
 */
const webpackConfig = require('@vue/cli-service/webpack.config.js')
module.exports = webpackConfig
